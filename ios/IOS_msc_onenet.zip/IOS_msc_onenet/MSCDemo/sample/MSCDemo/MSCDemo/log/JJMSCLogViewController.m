//
//  JJMSCLogViewController.m
//  MSCDemo
//
//  Created by haifeng on 2018/10/24.
//

#import "JJMSCLogViewController.h"
#import <MessageUI/MessageUI.h>
#import "PopupView.h"

@interface JJMSCLogViewController ()<MFMailComposeViewControllerDelegate>

@property (weak, nonatomic) IBOutlet UITextView *logTextView;
@property (nonatomic, strong) UIPasteboard *pab;
@property (nonatomic,strong) PopupView  *popUpView;

@property (nonatomic, strong) NSString *logFilePath;

@end

@implementation JJMSCLogViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.pab = [UIPasteboard generalPasteboard];
    self.logTextView.editable = NO;
    CGFloat posY = self.view.frame.size.height * 0.5;
    _popUpView = [[PopupView alloc] initWithFrame:CGRectMake(100, posY, 0, 0) withParentView:self.view];
    
    UIBarButtonItem *reloadLogItem = [[UIBarButtonItem alloc] initWithTitle:@"删除日志" style: UIBarButtonItemStylePlain target:self action:@selector(cleanLog)];
    UIBarButtonItem *pasteLogItem = [[UIBarButtonItem alloc] initWithTitle:@"拷贝内容" style: UIBarButtonItemStylePlain target:self action:@selector(pasteLog)];
    UIBarButtonItem *mailLogItem = [[UIBarButtonItem alloc] initWithTitle:@"邮件" style: UIBarButtonItemStylePlain target:self action:@selector(sendEmailAction)];
    self.navigationItem.rightBarButtonItems = @[reloadLogItem, pasteLogItem, mailLogItem];
    
    self.logFilePath = [JJ_MSC_Log_Path stringByAppendingString:@"/msc.log"];
    
    [self loadLog];
}

- (void)loadLog {
    
    NSError *error = nil;
    NSString *logContent = [NSString stringWithContentsOfFile:self.logFilePath encoding:NSASCIIStringEncoding error: &error];
    if(logContent.length != 0) {
        self.logTextView.text = logContent;
    }else {
        self.logTextView.text = @"";
    }
}

- (void)cleanLog {
    
    BOOL exist = [[NSFileManager defaultManager] fileExistsAtPath:self.logFilePath];
    
    if (!exist) {
        [_popUpView showText:@"日志不存在"];
        return;
    }
    
    NSError *error = nil;
    BOOL rlt = [[NSFileManager defaultManager] removeItemAtPath:self.logFilePath error:&error];
    if (rlt) {
        [_popUpView showText:@"日志已删除，重新启动程序"];
        [self loadLog];
    }else {
        [_popUpView showText:@"日志删除失败"];
    }
}

- (void)pasteLog {
    NSString *string = self.logTextView.text;
    [self.pab setString:string];
}

- (void)sendEmailAction {
    
    if (![MFMailComposeViewController canSendMail]) {
        [_popUpView showText:@"前往Mail 设置邮箱信息"];
        return;
    }
    
    // 创建邮件发送界面
    MFMailComposeViewController *mailCompose = [[MFMailComposeViewController alloc] init];
    // 设置邮件代理
    [mailCompose setMailComposeDelegate:self];
    // 设置收件人
    [mailCompose setToRecipients:@[@"1362545379@qq.com"]];

    // 设置抄送人
//    [mailCompose setCcRecipients:@[@"coderhong@126.com"]];
    // 设置密送人
//    [mailCompose setBccRecipients:@[@"15690725786@163.com"]];
    // 设置邮件主题
    [mailCompose setSubject:@"msc.log"];
    //设置邮件的正文内容
    NSString *emailContent = @"msc日志";
    // 是否为HTML格式
    [mailCompose setMessageBody:emailContent isHTML:NO];
    // 如使用HTML格式，则为以下代码
    // [mailCompose setMessageBody:@"<html><body><p>Hello</p><p>World！</p></body></html>" isHTML:YES];
    //添加附件
//    UIImage *image = [UIImage imageNamed:@"qq"];
//    NSData *imageData = UIImagePNGRepresentation(image);
//    [mailCompose addAttachmentData:imageData mimeType:@"" fileName:@"qq.png"];
//    NSString *file = [[NSBundle mainBundle] pathForResource:@"EmptyPDF" ofType:@"pdf"];
    
    NSString *logFilePath = [JJ_MSC_Log_Path stringByAppendingString:@"/msc.log"];
    NSData *msclog = [NSData dataWithContentsOfFile:logFilePath];
    [mailCompose addAttachmentData:msclog mimeType:@"" fileName:@"msc.log"];
    // 弹出邮件发送视图
    [self presentViewController:mailCompose animated:YES completion:nil];
}

#pragma mark - MFMailComposeViewControllerDelegate的代理方法：
-(void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error{
    switch (result) {
        case MFMailComposeResultCancelled:
            [_popUpView showText:@"取消编辑"];
            break;
        case MFMailComposeResultSaved:
            [_popUpView showText:@"保存邮件"];
            break;
        case MFMailComposeResultSent:
            [_popUpView showText:@"发送"];
            break;
        case MFMailComposeResultFailed:
            [_popUpView showText:@"保存或发送邮件失败"];
            break;
    }
    // 关闭邮件发送视图
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)dealloc {
    
    NSLog(@"----------------------------dealloc");
}
@end
