//
//  DiagleView.m
//  MSCDemo_UI
//
//  Created by wangdan on 14-12-22.
//
//

#import <UIKit/UIKit.h>
#import "iflyMSC/IFlyISVRecognizer.h"
#import "iflyMSC/IFlyISVDelegate.h"
#import "UIPopoverListView.h"
#import "PopupView.h"


@interface iFlyNvpViewController : UIViewController<UIAlertViewDelegate,UIActionSheetDelegate>

@end
