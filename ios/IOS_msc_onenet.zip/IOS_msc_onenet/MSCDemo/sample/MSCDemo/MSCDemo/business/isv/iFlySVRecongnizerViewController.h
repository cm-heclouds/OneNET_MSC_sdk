//
//  iFlySVRecongnizerViewController.h
//  MSCDemo
//
//  Created by haifeng on 2017/5/31.
//
//

#import <UIKit/UIKit.h>
#import "iflyMSC/IFlySpeechUtility.h"
#import "Definition.h"
#import "PopupView.h"

@interface iFlySVRecongnizerViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    NSArray         *_functions;
    
    UITextView      *_thumbView;
    
    PopupView       * _popUpView;
}
@end
