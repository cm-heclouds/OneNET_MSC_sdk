//
//  ISRDataHander.h
//  MSC
//
//  Created by ypzhao on 12-11-19.
//  Copyright (c) 2012年 iflytek. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ISRDataHelper : NSObject

/**
 parse JSON data
 **/
+ (NSString *)stringFromJson:(NSString*)params;//


/**
 parse JSON data for cloud grammar recognition
 **/
+ (NSString *)stringFromABNFJson:(NSString*)params;

/**
 * 流式识别解析
 */
+ (NSString *)parseFlowRecogniResult: (NSArray *)results isLast:(BOOL)isLast;
/**
 * 清空流式识别当前结果的缓存
 */
+(void)clearResultCache;
@end
