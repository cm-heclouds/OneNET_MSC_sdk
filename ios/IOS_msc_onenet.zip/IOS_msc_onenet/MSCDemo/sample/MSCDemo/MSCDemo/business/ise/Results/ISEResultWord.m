//
//  ISEResultWord.m
//  IFlyMSCDemo
//
//  Created by 张剑 on 15/3/6.
//
//

#import "ISEResultWord.h"

@implementation ISEResultWord

@end
