//
//  ISRDataHander.m
//  MSC
//
//  Created by ypzhao on 12-11-19.
//  Copyright (c) 2012年 iflytek. All rights reserved.
//

#import "ISRDataHelper.h"

/** 流式识别结果容器 */
static NSMutableDictionary *__wordMap = nil;

@implementation ISRDataHelper

/**
 parse JSON data
 params,for example：
 {"sn":1,"ls":true,"bg":0,"ed":0,"ws":[{"bg":0,"cw":[{"w":"白日","sc":0}]},{"bg":0,"cw":[{"w":"依山","sc":0}]},{"bg":0,"cw":[{"w":"尽","sc":0}]},{"bg":0,"cw":[{"w":"黄河入海流","sc":0}]},{"bg":0,"cw":[{"w":"。","sc":0}]}]}
 **/
+ (NSString *)stringFromJson:(NSString*)params
{
    if (params == NULL) {
        return nil;
    }
    
    NSMutableString *tempStr = [[NSMutableString alloc] init];
    NSDictionary *resultDic  = [NSJSONSerialization JSONObjectWithData:
                                [params dataUsingEncoding:NSUTF8StringEncoding] options:kNilOptions error:nil];

    if (resultDic!= nil) {
        NSArray *wordArray = [resultDic objectForKey:@"ws"];
        
        for (int i = 0; i < [wordArray count]; i++) {
            NSDictionary *wsDic = [wordArray objectAtIndex: i];
            NSArray *cwArray = [wsDic objectForKey:@"cw"];
            
            for (int j = 0; j < [cwArray count]; j++) {
                NSDictionary *wDic = [cwArray objectAtIndex:j];
                NSString *str = [wDic objectForKey:@"w"];
                [tempStr appendString: str];
            }
        }
    }
    return tempStr;
}


/**
 parse JSON data for cloud grammar recognition
 **/
+ (NSString *)stringFromABNFJson:(NSString*)params
{
    if (params == NULL) {
        return nil;
    }
    NSMutableString *tempStr = [[NSMutableString alloc] init];
    NSDictionary *resultDic  = [NSJSONSerialization JSONObjectWithData:
                                [params dataUsingEncoding:NSUTF8StringEncoding] options:kNilOptions error:nil];
    
    NSArray *wordArray = [resultDic objectForKey:@"ws"];
        for (int i = 0; i < [wordArray count]; i++) {
            NSDictionary *wsDic = [wordArray objectAtIndex: i];
            NSArray *cwArray = [wsDic objectForKey:@"cw"];
            
            for (int j = 0; j < [cwArray count]; j++) {
                NSDictionary *wDic = [cwArray objectAtIndex:j];
                NSString *str = [wDic objectForKey:@"w"];
                NSString *score = [wDic objectForKey:@"sc"];
                [tempStr appendString: str];
                [tempStr appendFormat:@" Confidence:%@",score];
                [tempStr appendString: @"\n"];
            }
        }
    return tempStr;
}

/**
 * 流式识别解析
 */
+ (NSString *)parseFlowRecogniResult: (NSArray *)results isLast:(BOOL)isLast
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        __wordMap = [NSMutableDictionary dictionary];
    });
    
    NSMutableString *resultString = [[NSMutableString alloc] init];
    NSDictionary *dic = results[0];
    for (NSString *key in dic) {
        [resultString appendFormat:@"%@",key];
    }
    
    if (resultString == nil || resultString.length == 0) return @"";
    
    NSDictionary *resultDic  = [NSJSONSerialization JSONObjectWithData:
                                [resultString dataUsingEncoding:NSUTF8StringEncoding] options:kNilOptions error:nil];
    
    if (!resultDic) return @"";
    
    // 获取pgs字段
    NSString *pgs = [resultDic objectForKey:@"pgs"];
    NSString *sn = [(NSNumber *)[resultDic objectForKey:@"sn"] stringValue];
    
    // 如果为rpl, 删除范围句
    if([pgs isEqualToString:@"rpl"]) {
        NSArray *rgArr = [resultDic objectForKey:@"rg"];
        int begin = [(NSNumber *)rgArr[0] intValue];
        int end = [(NSNumber *)rgArr[1] intValue];
        
        for (int i=begin; i<=end; i++) {
            [__wordMap removeObjectForKey: [NSString stringWithFormat:@"%d", i]];
        }
    }
    
    // 存储当前句
    NSString *text = [self stringFromJson:resultString];
    [__wordMap setValue:text forKey:sn];
    
    NSArray *keys = [__wordMap allKeys];
    NSArray *sortedArray = [keys sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        return [obj1 compare:obj2 options:NSNumericSearch];
    }];
    
    NSMutableString *tempStr = [NSMutableString string];
    for (NSString *value in sortedArray) {
        [tempStr appendString:[__wordMap objectForKey:value]];
    }
    
    if (isLast) {
        [__wordMap removeAllObjects];
    }
    
    return tempStr;
}

/**
 * 清空流式识别当前结果的缓存
 */
+(void)clearResultCache {
    if (__wordMap) {
        [__wordMap removeAllObjects];
    }
}
@end
