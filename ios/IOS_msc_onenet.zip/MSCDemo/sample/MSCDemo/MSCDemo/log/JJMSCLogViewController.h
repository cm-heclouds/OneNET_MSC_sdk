//
//  JJMSCLogViewController.h
//  MSCDemo
//
//  Created by haifeng on 2018/10/24.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface JJMSCLogViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
