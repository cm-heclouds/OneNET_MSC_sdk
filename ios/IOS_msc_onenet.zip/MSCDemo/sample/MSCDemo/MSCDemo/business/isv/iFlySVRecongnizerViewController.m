//
//  iFlySVRecongnizerViewController.m
//  MSCDemo
//
//  Created by haifeng on 2017/5/31.
//
//


#import "iFlySVRecongnizerViewController.h"
#import "iFlyNvpViewController.h"
#import <QuartzCore/QuartzCore.h>

@interface iFlySVRecongnizerViewController ()

@property (nonatomic, weak)UITableView *tableView;
@end

@implementation iFlySVRecongnizerViewController
- (id) init
{
    self = [super init];
    _functions = [[NSArray alloc]initWithObjects:@"声纹",nil];
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"讯飞语音示例";
    
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 70000
    if ( IOS7_OR_LATER )
    {
        self.edgesForExtendedLayout = UIRectEdgeNone;
        self.extendedLayoutIncludesOpaqueBars = NO;
        self.modalPresentationCapturesStatusBarAppearance = NO;
        self.navigationController.navigationBar.translucent = NO;
    }
#endif
    
    UITextView* thumbView = [[UITextView alloc] initWithFrame:CGRectMake(Margin*2, Margin, self.view.frame.size.width-Margin*2, 80)];
    NSLog(@"%f",self.view.frame.size.width);
    thumbView.text =@" 本示例为讯飞语音iOS平台开发者提供声纹识别demo,旨在让用户能够快速开发出基于声纹识别接口的应用程序。";
    
    thumbView.layer.borderWidth = 1;
    thumbView.layer.cornerRadius = 8;
    [self.view addSubview:thumbView];
    thumbView.editable = NO;
    _thumbView = thumbView;
    
    thumbView.font = [UIFont systemFontOfSize:17.0f];
    
    [thumbView sizeToFit];
    
    UITableView * tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, thumbView.frame.origin.y + thumbView.frame.size.height+Margin , self.view.frame.size.width, self.view.frame.size.height- thumbView.frame.size.height) style:UITableViewStylePlain];
    _tableView = tableView;
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.tableFooterView = [[UIView alloc] init];
    [self.view addSubview:tableView];
    
    [UIButton appearance].tintColor=self.navigationItem.backBarButtonItem.tintColor;
    
    return self;
    
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _functions.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
    }
    
    cell.textLabel.text = [_functions objectAtIndex:indexPath.row];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell ;
}

#pragma mark - Table view delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if( indexPath.row == 0 ){
        iFlyNvpViewController * nvp = [[iFlyNvpViewController alloc] init];
        [self.navigationController pushViewController:nvp animated:YES];
        
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    
}

- (void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    
    _thumbView.frame = CGRectMake(Margin, 64+Margin, [UIScreen mainScreen].bounds.size.width - Margin*2, 80);
    _tableView.frame = CGRectMake(0, CGRectGetMaxY(_thumbView.frame) + Margin, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height - 64 - 64);
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
