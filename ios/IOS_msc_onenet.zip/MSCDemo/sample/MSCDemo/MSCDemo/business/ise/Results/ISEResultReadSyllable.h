//
//  ISEResultReadSyllable.h
//  IFlyMSCDemo
//
//  Created by 张剑 on 15/3/7.
//
//

#import "ISEResult.h"

@interface ISEResultReadSyllable : ISEResult

@end
