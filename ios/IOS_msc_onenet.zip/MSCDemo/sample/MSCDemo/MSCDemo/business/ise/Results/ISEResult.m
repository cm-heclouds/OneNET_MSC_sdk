//
//  ISEResult.m
//  IFlyMSCDemo
//
//  Created by 张剑 on 15/3/6.
//
//

#import "ISEResult.h"

@implementation ISEResult

-(NSString*) toString{
    return @"";
}

@end
