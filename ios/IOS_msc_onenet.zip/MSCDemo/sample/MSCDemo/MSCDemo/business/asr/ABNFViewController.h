//
//  ABNFViewController.h
//  MSCDemo
//
//  Created by iflytek on 13-6-6.
//  Copyright (c) 2013年 iflytek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IFlyMSC/IFlyMSC.h"

//forward declare
@class PopupView;
@class IFlyDataUploader;
@class IFlySpeechRecognizer;

/**
 demo of Grammar Recognition (ASR)
 
 Five steps to integrating Grammar Recognition as follows:
 1.Instantiate IFlySpeechRecognizer singleton and IFlyDataUploader;
 2.Upload grammar file and acquire grammarID. Please refer to the inteface of buildGrammer in ABNFViewController.m for specific implementation;
 3.Set recognition params, especially obtained grammarID above;
 4.Add IFlySpeechRecognizerDelegate methods selectively;
 5.Start recognition;
 */
@interface ABNFViewController : UIViewController


@end
