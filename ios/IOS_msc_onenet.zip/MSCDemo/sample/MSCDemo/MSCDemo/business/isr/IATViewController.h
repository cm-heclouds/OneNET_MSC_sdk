//
//  IATViewController.h
//  MSCDemo_UI
//
//  Created by wangdan on 15-4-28.
//
//

#import <UIKit/UIKit.h>
#import "IFlyMSC/IFlyMSC.h"

//forward declare
@class PopupView;
@class IFlyDataUploader;
@class IFlySpeechRecognizer;
@class IFlyPcmRecorder;

/**
 demo of Short Form ASR (IAT)

 Four steps to integrating Short Form ASR as follows:
 1.Instantiate IFlySpeechRecognizer singleton;
 2.Set recognition params;
 3.Add IFlySpeechRecognizerDelegate or IFlyRecognizerViewDelegate methods selectively;
 4.Start recognition;
 */
@interface IATViewController : UIViewController

@end
