//
//  OneNetSpeechUtility.h
//  IFlyMSC
//
//  Created by CoderHong on 2019/1/9.
//  Copyright © 2019 iflytek. All rights reserved.
//



#import <Foundation/Foundation.h>
#import "IFlySetting.h"

typedef enum {
    OneNetAuthStateNoAuth, // 没有鉴权
    OneNetAuthStating,     // 鉴权中
    OneNetAuthStateFail,   // 鉴权没通过
    OneNetAuthStateSuccess // 鉴权通过
} OneNetAuthState;

typedef enum {
    IFlyOffLineServiceTypeTTS = 1, // 离线合成
    IFlyOffLineServiceTypeASR = 2, // 离线命令词
    IFlyOffLineServiceTypeIVW = 3  // 离线唤醒
} IFlyOffLineServiceType;

typedef enum {
    OneNetAuthErrorFail = 1001, // 鉴权失败错误
    OneNetAuthErrorTimeOut = 1002 // 鉴权超时
} OneNetAuthError;

NS_ASSUME_NONNULL_BEGIN

@interface OneNetSpeechUtility : NSObject

// 鉴权状态
@property (nonatomic, assign, readonly) OneNetAuthState authState;
@property (nonatomic, assign, readonly) NSInteger authErrCode;

+ (instancetype)shareInstance;


- (void)initializeWithOneNetAppId:(NSString *)oneNetAppId logFile:(LOG_LEVEL)level showLogcat:(BOOL)isShowLogcat;

// 根据设备标识对离线进行鉴权
- (void)offLineAuthoffWithServiceType:(IFlyOffLineServiceType)serviceType
                 result:(void (^)(BOOL success, NSError *error))result;

/*!
 日志上传
 @param sid 会话id，必选
 @param type tts(语音合成)、asr(语音识别)、iat(语音听写)、sch(文本语义理解)、iat_sch(听写语义理解)、see(语音评测)、ivp(声纹识别).
 @param result 请求回掉.
 */
- (void)uploadLogInfoWithSid:(NSString *)sid
                      type:(NSString *)type
                      result:(void (^)(BOOL success, NSError *error))result;
@end

NS_ASSUME_NONNULL_END


